LLM_CONFIG = {
    "backend": "ollama",
    #"backend": "llama_cpp",

    "gguf_model_path": "gemma-2-9b-it-Q4_K_M.gguf",
    "ollama_model_name": "gemma3:4b",
    "ollama_base_url": "http://localhost:11434",

    "n_ctx": 2048,
    "n_gpu_layers": -1,
    "max_tokens": 200,
    "temperature": 0.1,
}

API_KEYS = {
    "anthropic": "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",
    "openai": "",
}